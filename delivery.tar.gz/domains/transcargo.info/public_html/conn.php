<?php
 
//MySQLi Procedural
$conn = mysqli_connect("localhost","transcar_info","bonalegit","transcar_transcargo");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>