<?php
//connect to mysql database
$con = mysqli_connect("localhost", "transcar_client", "bonalegit", "transcar_client") or die("Error " . mysqli_error($con));
?>