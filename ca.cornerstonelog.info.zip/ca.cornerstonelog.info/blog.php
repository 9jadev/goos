﻿   
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="description" content="Oil Shipping Companies Strategic To Maritime Activity"><meta name="viewport" content="width=device-width, initial-scale=1">
		<title> Oil Shipping Companies Strategic To Maritime Activity  Corner Stone Logistics Ltd.  </title>
		<style type="text/css">
		.chat-cmodule-header, .chat-cmodule-header, .chat-cmodule-widget-head{
	opacity: 0.7 !important;
	}
  .goog-te-combo, .goog-te-banner *, .goog-te-ftab *, .goog-te-menu *, .goog-te-menu2 *, .goog-te-balloon *{
      font-family: 'Montserrat', sans-serif !important ;
      text-decoration: none !important;
      font-size: 11pt !important;
      color: #666;
      display: none !important;
  }
  .goog-te-banner-frame{
      display: none !important;
  }
  .goog-te-gadget-simple {
      font-family: 'Montserrat', sans-serif !important ;
      font-size: 9pt !important;
      background-color: #333 !important;
      color: #626262 !important;
      -webkit-box-shadow: inset 0 0 2px 2px rgba(0,0,0,0.02) !important;
      box-shadow: inset 0 0 2px 2px rgba(0,0,0,0.02) !important;
      padding-top: 0px !important;
      padding-bottom: 0px !important;
      border-bottom: 0px !important;
      border-top: 0px !important;
      border-left: 0px !important;
      border-right: 0px !important;
  }
   .goog-te-gadget img{
       background-image: url("https://us.cornerstonelog.info/icons8-google-24.png") !important;
       background-position: 0px 0px !important;
       background-size: 19px !important;
       background-repeat: no-repeat !important;
   }
   .goog-te-gadget-simple .goog-te-menu-value{
       color: #f9f9f9 !important;
       font-size: 13px !important;
       font-weight: 700;
   }
   .goog-te-combo, .goog-te-banner *, .goog-te-ftab *, .goog-te-menu *, .goog-te-menu2 *, .goog-te-balloon *{
      font-family: 'Montserrat', sans-serif !important ;
      font-size: 10pt !important;
      text-decoration: none !important;
   }
   .goog-te-menu2{
      font-family: 'Montserrat', sans-serif !important ;
      font-size: 9pt !important;
      border: 1px solid #ffffff !important;
      background-color: #ff9600 !important;
      color: #fff !important;
   }
   .goog-te-menu-frame{
      -webkit-box-shadow: none !important;
      box-shadow: -1px 2px 20px 0px #4444447a !important;
   }
   .goog-te-menu2-item div, .goog-te-menu2-item:link div, .goog-te-menu2-item:visited div, .goog-te-menu2-item:active div {
      font-family: 'Montserrat', sans-serif !important ;
      border: 1px solid #ffffff !important;
      background-color: #ff9600 !important;
      color: #fff !important;
   }
   a:hover {
       text-decoration: none !important;
   }
   span[style] {
       color: #f9f9f9 !important;
   }
   body[style] {
       top: 0px !important;
   }
   iframe[style] {
      font-family: 'Montserrat', sans-serif !important ;
      border: 1px solid #ffffff !important;
      background-color: #ff9600 !important;
      color: #fff !important;
   }
   footer{
       border-bottom: 0px !important;
   }
  .ns-growl {
	top: 336px !important;
	left: 1000px !important;
	max-width: 330px;
	border-radius: 5px;
  }
  .ns-effect-genie {
	top: 336px !important;
	left: 1000px !important;
	background: #3c3c3c;
	opacity: 0.9;
    filter: alpha(opacity=30);
	box-shadow: 0 7px 6px rgba(0,0,0,0.1), 2px 4px 6px rgba(0,0,0,0.1);
   }
  .ns-effect-genie:hover {
	top: 336px !important;
	left: 1000px !important;
	background: #363636;
	opacity: 1;
    filter: alpha(opacity=40);
	box-shadow: 0 7px 6px rgba(0,0,0,0.1), 2px 4px 6px rgba(0,0,0,0.1);
  }
	.modalDialog:background {
		-webkit-filter: blur(2px);
    -moz-filter: blur(2px);
    -o-filter: blur(2px);
    -ms-filter: blur(2px);
    filter: blur(2px);
		
		-webkit-filter: blur(10px);     
    filter: blur(10px);
	} 
	
	button {
	border: none;
	padding: 0.6em 1.2em;
	background: #09397a;
	color: #fff;
	font-family: 'Lato', Calibri, Arial, sans-serif;
	font-size: 1em;
	letter-spacing: 1px;
	text-transform: uppercase;
	cursor: pointer;
	display: inline-block;
	margin: 3px 2px;
	border-radius: 2px;
    }

    button:hover {
	background: #849cbc;
   }

	.md-content {
	color: #333333;
	background: #fff;
	position: relative;
	border-radius: 0px;
	margin: 0 auto;
    }

    .md-content h3 {
	color: #fff;
	margin: 0;
	padding: 0.4em;
	text-align: center;
	font-size: 2.4em;
	font-weight: 300;
	opacity: 10;
	background: #ff9600;
	border-radius: 0px 0px 0px 0px;
    }

   .md-content > div {
	padding: 15px 40px 30px;
	margin: 0;
	font-weight: 300;
	font-size: 1.15em;
    }

   .md-content > div p {
	margin: 0;
	padding: 10px 0;
    }

   .md-content > div ul {
	margin: 0;
	padding: 0 0 30px 20px;
    }

   .md-content > div ul li {
	padding: 5px 0;
   }

   .md-content button {
	display: block;
	margin: 0 auto;
	font-size: 0.8em;
   }

	
	.modalDialog {
		position: fixed;
		font-family: Arial, Helvetica, sans-serif;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		background: rgba(1,1,1,0.8) ;
		z-index: 99999;
		opacity:0;
		-webkit-transition: opacity 400ms ease-in;
		-moz-transition: opacity 400ms ease-in;
		transition: opacity 400ms ease-in;
		pointer-events: none;
		
		
	}
	.modalDialog:background {
		-webkit-filter: blur(10px);     
    filter: blur(10px);
		
		
	}
	
	
	<!--stopoper {
    -webkit-transform: translateY(0);
	-moz-transform: translateY(0);
	-ms-transform: translateY(0);
	transform: translateY(0);
	opacity: 1;
	-webkit-transition: all 0.5s 0.1s;
	-moz-transition: all 0.5s 0.1s;
	transition: all 0.5s 0.1s;
    }-->

	.modalDialog:target {
		opacity:20;
		pointer-events: auto;
	}

	.modalDialog > div {
		width: 600px;
		position: relative;
		margin: 10% auto;
		padding: 5px 20px 13px 20px;
		border-radius: 0px;
		
	}

	.close {
		-webkit-border-radius: 12px;
		-moz-border-radius: 12px;
		border-radius: 12px;
		-moz-box-shadow: 1px 1px 3px #000;
		-webkit-box-shadow: 1px 1px 3px #000;
		box-shadow: 1px 1px 3px #000;
	}

	.close:hover { background: #00d9ff; }
	</style>
  <link href="http://fonts.googleapis.com/css?family=Raleway:400,300,700" rel="stylesheet" type="text/css">
  <link rel="stylesheet" type="text/css" href="server-side\css_pop\ns-default.css">
  <link rel="stylesheet" type="text/css" href="server-side\css_pop\ns-style-growl.css">
  <script src="server-side\js_pop\modernizr.custom.js"></script>
		<link rel="shortcut icon" href="favicon.ico">

		<link href="css\master.css" rel="stylesheet">
		
		<link rel='stylesheet' id='style-css' href='css\style1.css' type='text/css' media='all'>
		<link rel='stylesheet' id='local-css' href='css\copywriter.css' type='text/css' media='all'>
		<link rel='stylesheet' id='custom-css' href='css/custom.css' type='text/css' media='all'>
		<script type="text/javascript" src="js\jquery-1.11.0.min.js"></script>
        <script type="text/javascript" src="js\jquery.leanModal.min.js"></script>
        <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
        <link type="text/css" rel="stylesheet" href="css\style.css">

		<!-- SWITCHER -->
		<link rel="stylesheet" id="switcher-css" type="text/css" href="assets\switcher\css\color4.css" media="all">
		<link rel="alternate stylesheet" type="text/css" href="assets\switcher\css\color1.css" title="color1" media="all">
		<link rel="alternate stylesheet" type="text/css" href="assets\switcher\css\color2.css" title="color2" media="all">
		<link rel="alternate stylesheet" type="text/css" href="assets\switcher\css\color3.css" title="color3" media="all">
		<link rel="alternate stylesheet" type="text/css" href="assets\switcher\css\color4.css" title="color4" media="all">
		<link rel="alternate stylesheet" type="text/css" href="assets\switcher\css\color5.css" title="color5" media="all">
		<link rel="alternate stylesheet" type="text/css" href="assets\switcher\css\color6.css" title="color6" media="all">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

		<!--[if lt IE 9]>
		<script src="//oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="//oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body data-scrolling-animations="true" style="position: relative; min-height: 100%; top: 0px;">
		<div class="sp-body">
		    <!-- Loader Landing Page -->
			<div id="ip-container" class="ip-container">
				<div class="ip-header">
					<div class="ip-loader">
						<svg class="ip-inner" width="60px" height="60px" viewbox="0 0 80 80">
							<path class="ip-loader-circlebg" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,39.3,10z"></path>
							<path id="ip-loader-circle" class="ip-loader-circle" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"></path>
						</svg> 
					</div>
				</div>
			</div>
			<!-- Loader end -->
			<!-- Start Switcher 
			<div class="switcher-wrapper">	
				<div class="demo_changer">
					<div class="demo-icon customBgColor"><i class="fa fa-cog fa-spin fa-2x"></i></div>
					<div class="form_holder">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="predefined_styles">
									<div class="skin-theme-switcher">
										<h4>Color</h4>
										<a href="#" data-switchcolor="color1" class="styleswitch" style="background-color:#a91605;"> </a>
										<a href="#" data-switchcolor="color2" class="styleswitch" style="background-color:#228dcb;"> </a>
										<a href="#" data-switchcolor="color3" class="styleswitch" style="background-color:#00bff3;"> </a>							
										<a href="#" data-switchcolor="color4" class="styleswitch" style="background-color:#ff9600;"> </a>
										<a href="#" data-switchcolor="color5" class="styleswitch" style="background-color:#2dcc70;"> </a>
										<a href="#" data-switchcolor="color6" class="styleswitch" style="background-color:#6054c2;"> </a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div> -->
			<header id="this-is-top">
				<div class="container-fluid">
					<div class="topmenu row">
						<nav class="col-sm-offset-3 col-md-offset-4 col-lg-offset-4 col-sm-6 col-md-5 col-lg-5">
							WELCOME TO  CORNER STONE LOGISTICS LTD.  
						</nav>
						<nav class="text-right col-sm-3 col-md-3 col-lg-3">
						<div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
							
						</nav>
					</div>
					<div class="row header">
						<div class="col-sm-3 col-md-3 col-lg-3">
							<a href="index.htm" id="logo"></a>
						</div>
						<div class="col-sm-offset-1 col-md-offset-1 col-lg-offset-1 col-sm-8 col-md-8 col-lg-8">
							<div class="text-right header-padding">
								<div class="h-block"><span>CALL US</span> +14242758608 </div>
								<div class="h-block"><span>EMAIL US</span> info@ca.cornerstonelog.info  </div>
								<div class="h-block"><span>WORKING HOURS</span>Mon - Sun  12.00 - 12.00</div>
								<a class="btn btn-success" href="contact.htm">GET A FREE QUOTE</a>
							</div>
						</div>
					</div>
					<div id="main-menu-bg"></div>  
					<a id="menu-open" href="#"><i class="fa fa-bars"></i></a> 
					<nav class="main-menu navbar-main-slide">
						<ul class="nav navbar-nav navbar-main">
						    <li><a href="index.htm">HOME</a></li>
							<li><a href="services.htm">OUR SERVICES</a></li>
							<li><a href="about.htm">ABOUT US</a></li>
						    <li><a href="blog.htm">BLOG</a></li>
							<li><a href="tracking_trace.htm">TRACKING / TRACE</a></li>
							<li><a href="contact.htm">CONTACT</a></li>
							<li><a class="btn_header_search" href="#"><i class="fa fa-search"></i></a></li>
						</ul>
						<div class="search-form-modal transition">
							<form class="navbar-form header_search_form">
								<i class="fa fa-times search-form_close"></i>
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Search">
								</div>
								<button type="submit" class="btn btn_search customBgColor">Search</button>
							</form>
						</div>
	                </nav>
					<a id="menu-close" href="#"><i class="fa fa-times"></i></a> 
				</div>
				
			</header> 

			<div class="bg-image page-title">
				<div class="container-fluid">
					<a href="#"><h1>Blog</h1></a>
					<div class="pull-right">
						<a href="index.htm"><i class="fa fa-home fa-lg"></i></a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href=" http://ca.cornerstonelog.info/09_blog.php">Blog</a>&nbsp;&nbsp;|&nbsp;&nbsp; <a href="#">Recent Posts</a>
					</div>
				</div>
			</div>

			<div class="container-fluid block-content">
				<div class="row main-grid">
					<div class="col-sm-9 posts">
						<div class="small-posts">
							<div class="wow fadeInUp" data-wow-delay="0.3s">
								<div class="post-info">
									<span>BY ADMIN</span>
									<span>NOVEMBER 29, 2016</span>
									<span>Delivery, Cargo, Shipment</span>
									<span>0 Comment(s)</span>
								</div>
								<img src="media\blog\8.jpg" alt="Img">
								<h1>Why Choose To Go With A Courier Service?</h1>
								<div class="post-content">
									<p>If you’re sending a package locally, you have the choice of whether to go through the regular post, or through a courier company. While the latter is generally more expensive, there are numerous advantages that come from going with this option. Let’s take a look at some of the reasons you may choose to go with a professional courier delivery service...</p>
								</div>
								<a href="11_blog-details.htm" class="btn btn-success btn-default read-more">READ MORE</a>
							</div>
							<div class="wow fadeInUp" data-wow-delay="0.3s">
								<div class="post-info">
									<span>BY ADMIN</span>
									<span>AUGUST 14, 2016</span>
									<span>Delivery, Cargo, Shipment</span>
									<span>0 Comment(s)</span>
								</div>
								<img src="media\blog\9.jpg" alt="Img">
								<h1>The Journey of the Courier Service from Past to Present</h1>
								<div class="post-content">
									<p>Traditionally delivery services were very much inconvenient and expensive. On the other hand carrying extra luggage and heavy loads from one country to another was very much restricted. In the past, people struggled to get their parcels to their loved ones as it was both costly and risky. Parcels were known to go missing, be labelled as undeliverables and get returned to the sender, or simply take an incredibly long time to reach the recipient.In fact we have discussed some interesting facts about courier service in the past in this post...</p>
								</div>
								<a href="12_blog.htm" class="btn btn-success btn-default read-more">READ MORE</a>
							</div>
							<div class="wow fadeInUp" data-wow-delay="0.3s">
								<div class="post-info">
									<span>BY ADMIN</span>
									<span>OCTOBER 4, 2016</span>
									<span>Delivery, Cargo, Shipment</span>
									<span>0 Comment(s)</span>
								</div>
								<img src="media\blog\10.jpg" alt="Img">
								<h1>How to Steer Clear of Airline Excess Baggage Charges</h1>
								<div class="post-content">
									<p>With more low-cost airlines operating out of Turkey than ever before and technology enabling us to buy flights anytime anywhere, traveling between countries has never been easier. But if you are planning to travel as inexpensively as possible, prepare to travel light. Excess baggage fees can add quite a bit to the overall price of your ticket and some providers (particularly low-cost airlines) will penalize you if you fail to adhere to their requirements...</p>
								</div>
								<a href="13_blog-details.htm" class="btn btn-success btn-default read-more">READ MORE</a>
							</div>
							<div class="wow fadeInUp" data-wow-delay="0.3s">
								<div class="post-info">
									<span>BY ADMIN</span>
									<span>JUN 29, 2015</span>
									<span>Delivery, Cargo, Shipment</span>
									<span>0 Comment(s)</span>
								</div>
								<img src="media\blog\11.jpg" alt="Img">
								<h1>5 Helpful Packing Tips When Shipping Goods</h1>
								<div class="post-content">
									<p>More people than ever are shipping goods around Australia and worldwide and with quality courier delivery providers that can transport just about anything from point A to point B, it’s never been more easy. In all but a few cases, the sender will need to prepare the package they are sending, so if you’re in this position it’s good to have a rough idea to pack in the very best way for a secured baggage freight...</p>
								</div>
								<a href="14_blog-details.htm" class="btn btn-success btn-default read-more">READ MORE</a>
							</div>
							<div class="wow fadeInUp" data-wow-delay="0.3s">
								<div class="post-info">
									<span>BY ADMIN</span>
									<span>MAY 15, 2015</span>
									<span>Delivery, Cargo, Shipment</span>
									<span>0 Comment(s)</span>
								</div>
								<img src="media\blog\12.jpg" alt="Img">
								<h1>Oil Shipping Companies Strategic To Maritime Activity </h1>
								<div class="post-content">
									<p>The pulse of a nation’s economy lies with its regular and controlled maritime activity. Trade and commerce via sea routes have provided benefits to millions of people worldwide. The transportation handled by oil shipping companies account for nearly 70% of trading activity via seaports. Natural resources derived from West Africa have shown that such companies are the main catalyst for the development of the economy in the region. Cargo operations by sea and airports require the best and experienced brains. All marine logistics handlers need onshore and offshore expertise that is the mainstay of such firms. Then only can they be the chief driver of a rising economy...</p>
								</div>
								<a href="15_blog-details.htm" class="btn btn-success btn-default read-more">READ MORE</a>
							</div>
						</div>
						<nav class="pagination wow fadeInUp" data-wow-delay="0.3s">
							<a href="11_blog-details.htm">1</a>
							<a href="12_blog.htm" class="active">2</a>
							<a href="13_blog-details.htm">3</a>
							<a href="14_blog-details.htm">4</a>
							<a href="15_blog-details.htm">5</a>
						</nav>                    
					</div>
					<div class="col-sm-3">
						<div class="sidebar-container">
							<div class="wow slideInUp" data-wow-delay="0.3s">
								<form class="search-form" action="#" method="post">
									<input type="text" placeholder="Search Blog" name="query">
									<input type="submit" name="Search" value="Search" class="hidden">
									<i class="fa fa-search"></i>
								</form>
							</div>
							<div class="wow slideInUp" data-wow-delay="0.3s">
								<h4>Categories</h4>
								<ul class="blog-cats">
									<li><a href=" http://ca.cornerstonelog.info/09_blog.php">Sea Freight</a></li>
									<li><a href=" http://ca.cornerstonelog.info/09_blog.php">Door-to-Door Delivery</a></li>
									<li><a href=" http://ca.cornerstonelog.info/09_blog.php">Latest Shipments</a></li>
									<li><a href=" http://ca.cornerstonelog.info/09_blog.php">Road Ways Cargo</a></li>
									<li><a href=" http://ca.cornerstonelog.info/09_blog.php">Railway Logistics</a></li>
									<li><a href=" http://ca.cornerstonelog.info/09_blog.php">Cargo Services</a></li>
								</ul>
							</div>
														<div class="recent-posts wow slideInUp" data-wow-delay="0.3s">
								<h4>Recent posts</h4>
								<div>
									<img src="media/blog/1.jpg" alt="Img">
									<a href="11_blog-details.htm">The Journey of the Courier Service from Past to Present</a>
									<span>AUGUST 14, 2016</span>
								</div>
								<div>
									<img src="media/blog/2.jpg" alt="Img">
									<a href="11_blog-details.htm">How to Steer Clear of Airline Excess Baggage Charges</a>
									<span>OCTOBER 4, 2016</span>
								</div>
								<div>
									<img src="media/blog/3.jpg" alt="Img">
									<a href="11_blog-details.htm">5 Helpful Packing Tips When Shipping Goods</a>
									<span>JUN 29, 2015</span>
								</div>
								<div>
									<img src="media/blog/4.jpg" alt="Img">
									<a href="11_blog-details.htm">Oil Shipping Companies Strategic To Maritime Activity</a>
									<span>MAY 15, 2015</span>
								</div>
							</div>
							<div class="tags wow slideInUp" data-wow-delay="0.3s">
								<h4>Tags</h4>
								<a href="#">Logistics</a>
								<a href="#">How to Build</a>
								<a href="#">Basic Tricks</a>
								<a href="#">Tips</a>
								<a href="#">Cargo Services</a>
								<a href="#">Sea & Trucking </a>
								<a href="#">Latest Offers</a>
							</div>
							
						</div>
					</div>                	
				</div>            
			</div>

			
			   <footer>
				<div class="color-part2"></div>
				<div class="color-part"></div>
				<div class="container-fluid">
					<div class="row block-content">
						<div class="col-xs-8 col-sm-4 wow zoomIn" data-wow-delay="0.3s">
							<a href="#" class="logo-footer"></a>
							<p> Corner Stone Logistics Ltd.   is a wholly Turkish owned company incorporated in 2007 to provide seamless shipping & logistics services to esteemed customers with branches in accross the globe. This has remained the vision of CSL since incorporation but the dynamics of our<br> services has evolved over the years.</p>
							<div class="footer-icons">
								<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-google-plus-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-pinterest-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-vimeo-square fa-2x"></i></a>
							</div>
							<a href="contact.htm" class="btn btn-lg btn-danger">GET A FREE QUOTE</a>
						</div>
						<div class="col-xs-4 col-sm-2 wow zoomIn" data-wow-delay="0.3s">
							<h4>OUR OFFERS</h4>
							<nav>
								<a href="services.htm">Sea Freight</a>
								<a href="services.htm">Land Logisticis</a>
								<a href="services.htm">Air Freight</a>
								<a href="services.htm">Packaging & Removal</a>
								<a href="services.htm">Warehousing</a>
							</nav>
						</div>
						<div class="col-xs-6 col-sm-2 wow zoomIn" data-wow-delay="0.3s">
							<h4>MAIN LINKS</h4>
							<nav>
								<a href="index.htm">Home</a>
	                            <a href="services.htm">Our Services</a>
	                            <a href="about.htm">About Us</a>
	                            <a href="blog.htm">Blog</a>
	                            <a href="tracking_trace.htm">Tracking / Trace</a>
	                            <a href="contact.htm">Contact</a>
							</nav>
						</div>
						<div class="col-xs-6 col-sm-4 wow zoomIn" data-wow-delay="0.3s">
							<h4>CONTACT INFO</h4>
							 This branch of Corner Stone Logistics Ltd. is also located in Califonia							<div class="contact-info">
								<span><i class="fa fa-location-arrow"></i><strong> CORNER STONE LOGISTICS LTD.</strong><br>416 E Girard Ave apt c muscle shoals AL 35661 </span>
								<span><i class="fa fa-phone"></i> +14242758608 </span>
								<span><i class="fa fa-envelope"></i> info@ca.cornerstonelog.info    |    <br>billing@ca.cornerstonelog.info </span>
								<span><i class="fa fa-clock-o"></i>Mon - Sun  12.00 - 12.00</span>
							</div>
						</div>
					</div>
					<div class="copy text-right"><a id="to-top" href="#this-is-top"><i class="fa fa-chevron-up"></i></a>&copy; 2017 <a href="#"> Corner Stone Logistics Ltd.   </a>- All rights reserved.</div>
				</div>
			</footer>
			<div ng-app="cmodule" ng-controller="BodyController">
    <div ng-view=""></div>
    <style ng-bind-html="custom_styles"></style>
</div>
<link href="livechat\assets\cmodule-chat\css\cmodule-chat.css" rel="stylesheet">
<link href="livechat\assets\angular-rangeslider-directive-master\angular-range-slider.css" rel="stylesheet">
<link href="livechat\assets\scrollbar-plugin\css\jquery.mCustomScrollbar.css" rel="stylesheet">
<script src="livechat\assets\cmodule-chat\js\jquery.min.js"></script>
<script>
    var site_url = 'http://ca.cornerstonelog.info/livechat/index.php/';
</script>
<script src="livechat\assets\scrollbar-plugin\js\jquery.mCustomScrollbar.concat.min.js"></script>
<script src="livechat\assets\cmodule-chat\js\angular.min.js"></script>
<script src="livechat\assets\cmodule-chat\js\sanitize.js"></script>
<script src="livechat\assets\cmodule-chat\js\angular-route.js"></script>
<script src="livechat\assets\angular-rangeslider-directive-master\angular-range-slider.min.js"></script>
<script src="livechat\assets\cmodule-chat\js\app.js"></script>
<!-- REQUIRED JS SCRIPTS -->
<script src="server-side\js_pop\classie.js"></script>
<script src="server-side\js_pop\notificationFx.js"></script>
<script>// create the notification
var notification = new NotificationFx({

	// element to which the notification will be appended
	// defaults to the document.body
	wrapper : document.body,

	// the message
	message :   ,

	// layout type: growl|attached|bar|other
	layout : 'growl',

	// effects for the specified layout:
	// for growl layout: scale|slide|genie|jelly
	// for attached layout: flip|bouncyflip
	// for other layout: boxspinner|cornerexpand|loadingcircle|thumbslider
	// ...
	effect : 'scale',

	// notice, warning, error, success
	// will add class ns-type-warning, ns-type-error or ns-type-success
	type : 'error',

	// if the user doesn´t close the notification then we remove it 
	// after the following time
	ttl : 6000,

	// callbacks
	onClose : function() { return false; },
	onOpen : function() { return false; }

});

// show the notification
notification.show();</script>

<script>// create the notification
var notification = new NotificationFx({

	// element to which the notification will be appended
	// defaults to the document.body

	// the message
	message :   ,

	// layout type: growl|attached|bar|other
	layout : 'growl',
							effect : 'genie',
							type : 'notice',

	// if the user doesn´t close the notification then we remove it 
	// after the following time
	ttl : 6000,

	// callbacks
	onClose : function() { return false; },
	onOpen : function() { return false; }

});

// show the notification
notification.show();</script>
		<!--Main-->   
		<script src="js\jquery-1.11.3.min.js"></script>
		<script src="js\jquery-ui.min.js"></script>
		<script src="js\bootstrap.min.js"></script>
		<script src="js\modernizr.custom.js"></script>
		<!-- Loader -->
		<script src="assets\loader\js\classie.js"></script>
		<script src="assets\loader\js\pathLoader.js"></script>
		<script src="assets\loader\js\main.js"></script>
		<script src="js\classie.js"></script>
		<!--Switcher-->
		<script src="assets\switcher\js\switcher.js"></script>
		<!--Owl Carousel-->
		<script src="assets\owl-carousel\owl.carousel.min.js"></script>
        <!-- SCRIPTS -->
	    <script type="text/javascript" src="assets\isotope\jquery.isotope.min.js"></script>
		<!--Theme-->
		<script src="js\jquery.smooth-scroll.js"></script>
		<script src="js\wow.min.js"></script>
		<script src="js\jquery.placeholder.min.js"></script>
		<script src="js\smoothscroll.min.js"></script>
		<script src="js\theme.js"></script>
	</div></body>
</html> 	