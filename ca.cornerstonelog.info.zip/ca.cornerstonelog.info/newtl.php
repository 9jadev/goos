<?php
	include('conn.php');
 
	$trackid= mysqli_real_escape_string($conn, $_POST['trackid']);
	$date=  mysqli_real_escape_string($conn, $_POST['date']);
	$location=  mysqli_real_escape_string($conn, $_POST['location']);
	$status=  mysqli_real_escape_string($conn, $_POST['status']);
	$time=  mysqli_real_escape_string($conn, $_POST['time']);
 
	if(mysqli_query($conn,"INSERT into info (trackid, dates, location, status, time) VALUES ('$trackid', '$date', '$location', '$status', '$time')")){
	header('location:admin.php');

	};
 
?>