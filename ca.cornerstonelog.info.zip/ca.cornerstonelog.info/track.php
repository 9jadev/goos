<?php
session_start();

if(isset($_SESSION['user_trackid'])!="") {
    header("Location: tracking.php");
}

include_once 'dbconnect.php';

//check if form is submitted
if (isset($_POST['track'])) {

    $trackid = mysqli_real_escape_string($con, $_POST['trackid']);
    $result = mysqli_query($con, "SELECT * FROM client WHERE trackid = '" . $trackid. "'");

    if ($row = mysqli_fetch_array($result)) {
        $_SESSION['user_trackid'] = $row['trackid'];
        $_SESSION['user_date'] = $row['dates'];
        $_SESSION['user_delivery'] = $row['delivery'];
        $_SESSION['user_type'] = $row['type'];

        header("Location: tracking.php");
    } else {
        $errormsg = "Invalid tracking id";
                header("Location: tracking_trace.htm");

    }
}
?>