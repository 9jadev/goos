<?php
	include('dbconnect.php');
 
	$trackid= mysqli_real_escape_string($con, $_POST['trackid']);
	$date=  mysqli_real_escape_string($con, $_POST['date']);
	$type=  mysqli_real_escape_string($con, $_POST['type']);
	$delivery=  mysqli_real_escape_string($con, $_POST['delivery']);
 
	if(mysqli_query($con,"INSERT into client (trackid, dates, type, delivery) VALUES ('$trackid', '$date', '$type', '$delivery')")){
	header('location:admin.php');

	};
 
?>